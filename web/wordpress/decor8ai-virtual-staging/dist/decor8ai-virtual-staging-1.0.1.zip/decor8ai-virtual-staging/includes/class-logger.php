<?php
if (!defined('ABSPATH')) {
    exit;
}

class Decor8_VS_Logger {
    private static $instance = null;
    private $log_file;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $upload_dir = wp_upload_dir();
        $this->log_file = trailingslashit($upload_dir['basedir']) . 'decor8-virtual-staging.log';
    }

    public function log($message, $type = 'info') {
        $timestamp = date('Y-m-d H:i:s');
        $formatted_message = sprintf("[%s] [%s] %s\n", $timestamp, strtoupper($type), $message);
        file_put_contents($this->log_file, $formatted_message, FILE_APPEND);
    }

    public function get_log_path() {
        return $this->log_file;
    }

    public function clear_log() {
        file_put_contents($this->log_file, '');
    }
}